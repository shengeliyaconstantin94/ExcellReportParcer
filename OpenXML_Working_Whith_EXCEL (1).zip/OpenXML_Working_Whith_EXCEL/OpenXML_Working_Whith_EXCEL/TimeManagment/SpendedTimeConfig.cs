﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenXML_Working_Whith_EXCEL
{
    class SpendedTimeConfig
    {
        public int Incident4LowPriorityTimeCosts { get; set; }
        public int Incident3MediumPriorityTimeCosts { get; set; }
        public int RevisionUnknownPriorityTimeCosts { get; set; }
        public int ConsultationLowPriorityTimeCosts { get; set; }
        public int StandartServiceRequestTimeCosts { get; set; }
        public int ConsultationMediumPriorityTimeCosts { get; set; }
        public int Incident1ExtremeHighPriorityTimeCosts { get; set; }
        public int TuningServiceRequestTimeCosts { get; set; }
        

    }
}
